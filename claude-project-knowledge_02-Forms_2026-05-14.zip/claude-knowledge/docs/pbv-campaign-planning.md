# PBV Conversion — Campaign Planning

**Date:** April 22, 2026
**For:** Dan intake call
**System:** form-stanton.vercel.app (compliance platform)

---

## Overview

Converting tenants to Project-Based Voucher (PBV) requires collecting a full HCV application package from each household. We can run this as a compliance campaign using the existing project/magic-link system — SMS tenants a unique link, they complete tasks, staff tracks completion in the matrix.

---

## Campaign 1: PBV Tenant Intake

### What We Need From Each Household

#### A. Information (collected via form)

| Category | Fields |
|----------|--------|
| **Household composition** | Every person in unit: name, DOB, SSN, relationship, disability Y/N, student Y/N (adults), citizenship status |
| **Minors** | Name, DOB, SSN, relationship, age, disability Y/N, citizenship |
| **Demographics** | Race, ethnicity, marital status |
| **Contact** | Phone (home/work/cell), email, alternate contact name + phone |
| **Income — all adults** | Employment (multiple), pension, SSI, SS, railroad retirement, child support/alimony, TANF, food stamps, self-employment, unemployment, workers comp, rental/asset income, regular contributions/gifts, paid training, grants/scholarships, Cash App/Zelle/Venmo/PayPal, other |
| **Zero income** | Declaration if any adult claims zero income; does anyone outside household help with bills? |
| **Assets** | Real estate, stocks, savings, checking, insurance settlements, CDs, trusts, bonds, life insurance |
| **Asset disposal** | Sold or given away assets in last 2 years? |
| **Childcare expenses** | Pay for childcare under 14 or disabled member? Care 4 Kids? Pay relative/friend? |
| **Medical expenses** | Only if head/spouse disabled or 62+ — insurance, doctor visits, prescriptions |
| **Criminal history** | Violent activity, alcohol, meth, drug possession/sale/distribution, sex offender registry, other convictions — per household member regardless of age |
| **DV status** | Victim of domestic violence? |
| **Homeless at admission** | Y/N |
| **Reasonable accommodation** | Need any? |
| **Household expenses** | Rent, utilities, vehicle payment/insurance, cable/internet, phones, childcare, furniture rental, loans, credit cards, groceries, takeout, grooming, cleaning, gas, clothing, entertainment, household items, vehicle maintenance, medical, alcohol/tobacco — amounts + who pays |

#### B. Documents to Upload (per household member where applicable)

| Document | When Needed |
|----------|-------------|
| 4 weekly or 2 bi-weekly paystubs | Per employed member |
| Pension/retirement award letter | If receiving |
| SSI award letter | If receiving |
| SS award letter | If receiving |
| Railroad retirement letter | If receiving |
| Child support court order or payment history | If receiving |
| TANF benefit letter | If receiving |
| Food stamps benefit letter | If receiving |
| Unemployment benefits letter | If receiving |
| Workers comp benefits letter | If receiving |
| Self-employment contract + earnings | If self-employed |
| Training program letter | If in paid training |
| School letter / grant documentation | If receiving grants/scholarships |
| Cash App/Zelle/Venmo/PayPal — 2 months statements | If receiving money through these |
| Bank statements — savings (last month) | If has savings account |
| Bank statements — checking (last months) | If has checking account |
| Insurance settlement letter | If has |
| CD/trust/bond statements | If has |
| Life insurance policy showing value | If has |
| Doctor's bills (last year) | If claiming medical deduction (disabled/62+) |
| Pharmacy statements (last year) | If claiming prescription deduction |
| Care 4 Kids certificate | If receiving |
| Citizenship/immigration docs (I-551, I-94, I-688, I-688B) | Non-citizens with eligible status |
| Proof of age | Non-citizens 62+ claiming eligible status |

#### C. Signatures Required (ALL adults 18+ must sign each)

| Form | Notes |
|------|-------|
| Main application attestation | Penalty of perjury |
| Criminal background release | HACH authorization |
| Child support OR no child support affidavit | One or the other |
| HUD-9886-A (Release of Information / Privacy Act) | Federal form, required |
| HACH Authorization for Release of Information | 15-month expiry |
| Obligations of Family | Program rules acknowledgment |
| Family Certification of Briefing Documents Received | Confirms receipt of 8 documents |
| Debts Owed to PHAs acknowledgment (HUD-52675) | All adults sign |
| Citizenship Declaration | All members, adults sign for minors |
| EIV Guide receipt | Confirmation of receipt |
| HUD-92006 Supplemental Contact | Optional but form must be signed |
| VAWA Certification (HUD-5382) | If applicable |
| Reasonable Accommodation request | If applicable |

#### D. Acknowledgments (read + confirm)

- VAWA notice
- Inspection policy (missed = termination warning)
- Lead paint brochure receipt
- Fraud warnings ("Is Fraud Worth It?" / "Things You Should Know")
- Fair housing discrimination info
- EIV guide

---

### How This Runs in Our System

**Project:** "PBV Conversion Intake"
**Mode:** Sequential (form first, then uploads, then staff review)
**Delivery:** SMS via Twilio — magic link per unit

#### Task Structure

| # | Task | Type | Assignee | Notes |
|---|------|------|----------|-------|
| 1 | PBV Intake Form | `form` | Tenant | All household info, income, assets, expenses, criminal history, all acknowledgments + signatures inline |
| 2 | Income Verification Docs | `file_upload` | Tenant | Paystubs, benefit letters, etc. |
| 3 | Bank Statements | `file_upload` | Tenant | Savings + checking |
| 4 | Asset Documentation | `file_upload` | Tenant | CDs, bonds, life insurance, etc. — waive if N/A |
| 5 | Citizenship/Immigration Docs | `file_upload` | Tenant | Waive if US citizen |
| 6 | Medical/Childcare Docs | `file_upload` | Tenant | Waive if N/A |
| 7 | Other Supporting Docs | `file_upload` | Tenant | Catch-all: child support orders, Cash App statements, etc. |
| 8 | Staff: Verify Income Docs | `staff_check` | Staff | Cross-reference form answers with uploaded docs |
| 9 | Staff: Verify Household Composition | `staff_check` | Staff | SSNs, DOBs, citizenship docs check out |
| 10 | Staff: Verify Completeness | `staff_check` | Staff | All signatures present, all required uploads received |

---

### Open Questions for Dan

- [ ] **Multi-signer:** Every adult 18+ must sign ~10 forms. Do we have one person (head of household) complete the magic link and collect all signatures on one device? Or do we need per-person links within a unit?
- [ ] **SSN collection:** The form collects SSNs. Are we comfortable collecting these digitally through the portal, or does this need to be paper/in-person only?
- [ ] **Which units are converting?** Need a list to scope the campaign.
- [ ] **Timeline/deadline?** When does HACH need completed packages?
- [ ] **Briefing documents:** The packet includes several "KEEP FOR YOUR INFORMATION" docs (lead paint, EIV guide, fraud warnings, fair housing). Do we just confirm receipt digitally, or do we need to physically distribute these?
- [ ] **Reasonable accommodation / VAWA forms:** These are conditional. Do we include them in the main flow as optional, or handle separately?
- [ ] **HUD form versions:** Some forms in the packet have expired OMB numbers (e.g., HUD-52675 expired 04/30/2023, HUD-92006 expired 02/28/2019). Do we need updated versions from HACH, or are we using their exact packet as-is?

---

## Campaign 2: Maintenance

**Status:** Need to define scope with Dan

### Questions to Clarify

- [ ] Is this **HQS inspections** (required annually for PBV/HCV units)? If so:
  - Who inspects — HACH inspector, our staff, or third party?
  - What's our role — scheduling access, collecting tenant availability, pre-inspection prep?
  - Do we need to collect anything from tenants (availability windows, access consent)?
- [ ] Is this **preventive maintenance rounds** (our own operational maintenance)?
  - What's the scope — smoke detectors, fire extinguishers, HVAC filters, pest control, general condition?
  - Dean doing walkthroughs? Or vendor-coordinated?
- [ ] Is this **work order tracking** — tenant-submitted maintenance requests?
  - Does this belong in the compliance system or in AppFolio?
- [ ] Or is this **unit turnover / make-ready** maintenance for PBV conversion prep?

### Possible Campaign Structures

**If HQS Inspection Prep:**
| # | Task | Type | Assignee |
|---|------|------|----------|
| 1 | Schedule inspection — confirm tenant availability | `form` | Tenant |
| 2 | Pre-inspection checklist (smoke alarms, outlets, etc.) | `form` | Tenant or Staff |
| 3 | Inspection completed | `staff_check` | Staff |
| 4 | Deficiency repairs completed | `staff_check` | Staff |
| 5 | Re-inspection passed | `staff_check` | Staff |

**If Preventive Maintenance Round:**
| # | Task | Type | Assignee |
|---|------|------|----------|
| 1 | Entry notice sent | `staff_check` | Staff |
| 2 | Unit walkthrough completed | `form` | Staff (Dean) |
| 3 | Work orders created for findings | `staff_check` | Staff |
| 4 | Work orders completed | `staff_check` | Staff |

---

## System Capabilities Reminder

What's already built and available:
- **Magic links** — unique per unit per project, SMS via Twilio
- **Task types:** form, file_upload, photo, signature, acknowledgment, staff_check
- **Sequential or parallel** task ordering
- **Trilingual** (EN/ES/PT) — portal auto-loads tenant's preferred language
- **Compliance matrix** — rows = units, columns = tasks, live status tracking
- **Bulk SMS send** from project management UI
- **Per-unit door notices with QR codes** — for in-person follow-up

What needs to be built for PBV:
- The actual intake form (big form, lots of conditionals)
- Document upload task templates for each category
- **Decision needed:** Multi-signer support (per-person vs per-unit)
- **Decision needed:** SSN handling approach
