# PBV Pre-Application — Field Specification

**Purpose:** Short qualification screen (~5–10 min). Determines if a household is likely to qualify before inviting them to the full application.
**Output:** Likely qualifies / Does not qualify — reviewed by both Stanton and the housing authority before advancing.

---

## Section 1: Head of Household

| Field | Type | Notes |
|---|---|---|
| Full name | Text | Must be an adult legally able to sign — children cannot be head of household |
| Unit number | Text / Dropdown | Drives bedroom count → income threshold lookup |
| Building address | Dropdown | Pre-populated from Stanton portfolio |

---

## Section 2: Household Members

Repeating group — one entry per occupant including head of household.

| Field | Type | Notes |
|---|---|---|
| Name | Text | |
| Age | Number | Used to determine if head of household is a minor |
| Annual income | Number | Per person — summed for household total |
| Relationship to head of household | Dropdown | Self / Spouse / Child / Other |

---

## Section 3: Citizenship Status

| Field | Type | Notes |
|---|---|---|
| Is the head of household a U.S. citizen or eligible non-citizen? | Yes / No | Preferred — program requires at least one in the household |
| If no: is there another adult in the household who is a U.S. citizen or eligible non-citizen? | Yes / No | Shown only if head of household is not a citizen |

**Rule:** At least one adult in the household must be a U.S. citizen or have eligible immigration status. If none, pre-app does not advance.

---

## Qualification Logic (Backend)

1. Pull bedroom count from unit number
2. Look up income threshold for household size + bedroom count
3. Sum all occupant income
4. If total income > threshold → likely does not qualify
5. If citizenship condition not met → does not qualify

**Hard vs. soft denial:** Not yet decided. Options:
- **Hard:** System blocks submission, shows "based on what you've entered, your household is unlikely to qualify"
- **Soft:** Submission goes through, staff + housing authority review before any decision is communicated

---

## Review Process

Pre-application summaries are reviewed by **both Stanton and the housing authority** before any household is advanced to the full application. This is not a unilateral Stanton decision.

---

## Form Requirements

- Trilingual: EN / ES / PT
- Digital signature at end (confirming info is accurate)
- Mobile-first
- Maps to Hartford Housing Authority (HC) application format where possible

---

## Open Items

| Item | Owner | Status |
|---|---|---|
| Income threshold table by household size / bedroom count | Dan / Alex | Open |
| Hard vs. soft auto-denial decision | Alex | Open |
| Confirm citizenship eligibility definition (citizen vs. eligible non-citizen) | Dan | Open |
| Confirm minimum age for head of household | Dan | Open — likely 18, possibly 16 |
