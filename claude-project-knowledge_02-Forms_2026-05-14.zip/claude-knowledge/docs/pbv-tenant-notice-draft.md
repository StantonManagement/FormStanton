# PBV Program — Tenant Notice (Draft v3)

---

Subject: Something we'd like to offer you

---

Dear [Tenant Name],

We've been looking for ways to build a more meaningful relationship with the people who live in our buildings — and we think we've found something worth sharing.

Through our partnership with the housing authority, we're in a position to award Section 8 rental assistance directly to select tenants. This is called a Project-Based Voucher. Most households wait ten to fifteen years on the public waitlist for something like this — many never receive it. We'd like to offer it to you now.

**What this would mean for you**

If your household qualifies and is selected, you'd pay roughly 30–40% of your household income toward rent. The housing authority covers the rest. For most families, that's a meaningful change.

**How it works**

There are a few steps, and we want to be clear about what's involved:

**Pre-Application — due [DATE]**
A short form, about five minutes. We'll ask who lives in your household, your approximate income, and a few basic details. We'll let you know quickly whether your household is likely to qualify.

**Full Application — due [DATE]**
For households that move forward, we'll ask for income documentation, identification, and a completed application. We'll guide you through what's needed.

**Unit Inspection**
The housing authority requires an inspection of your unit before benefits can begin. We'll be in touch about scheduling.

**Award**
Selected households will be notified and enrolled. From there, the lower rent takes effect going forward.

**How we'll make selections**

We want to be straightforward about this: the award is our decision to make, and we're going to make it thoughtfully. We'll be looking at financial qualification, of course — but also at the kind of tenancy someone has shown. Payment history, care of the unit, how the relationship with management has gone. We're looking for people who want to be here long-term and who treat the building as their home. That's who this is designed for.

We think this can be the beginning of something better for everyone involved. We hope you'll consider it.

To get started, complete the pre-application by **[DATE]**:

[Pre-Application Link]

If you have questions, we're at the office.

Stanton Management
421 Park Street, Hartford CT 06106
(860) 993-3401
