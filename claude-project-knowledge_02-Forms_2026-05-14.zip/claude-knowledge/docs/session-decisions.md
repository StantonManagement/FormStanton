# Session Decisions — April 22, 2026

---

## 1. Lobby Intake Hardening

Edge cases catalogued and a phased implementation plan exists (`Lobby Edge-Case Hardening Plan`). Key decisions still needed before build:

- **Canonical strategy:** newest record wins by default, or explicit staff selection when duplicates exist?
- **Manager override:** can staff issue a permit with a logged reason when checklist fails?

Print is the primary on-the-spot correction path (not sending a link). Lobby feature must support generating a printable, signable form at the desk.

---

## 2. PBV (Project-Based Voucher) Program

### What it is
Stanton can award Section 8 assistance directly to existing tenants via a Project-Based Voucher. Bypasses the public waitlist (typically 10–15 year wait). Discretionary — Stanton decides who gets it.

### Program structure
- **Pre-application:** Short qualification screen (~5 min). Tenant submits; Stanton + housing authority review. Output: likely qualifies / does not qualify.
- **Full application:** Invited tenants only. Income docs, ID, completed HC application form.
- **Unit inspection:** Housing authority requirement before benefits begin.
- **Award:** Selected households enrolled; reduced rent takes effect.

### Review process — important
Pre-application summaries require **both Stanton and the housing authority to review** before a household is advanced to the full application. This is not a unilateral Stanton decision at that stage.

### Two initiation rounds
- Round 1: ~July 1
- Round 2: ~September 1 (for households that needed more time / missed documentation)

### Selection criteria
Financial qualification is table-stakes, but selection also weighs:
- Payment history
- Lease compliance
- Care of unit and building
- Overall tenancy relationship

### Tenant-facing framing (locked)
- Lead with what's being offered and its value
- Frame as a partnership, not an entitlement
- Be explicit that it's discretionary and can be taken away
- Tie award to behavior and compliance without being punitive
- Voice & Values standard applies throughout

### Digital form requirements
- Trilingual: EN / ES / PT
- Digital signature
- Maps to Hartford Housing Authority (HC) application format
- Goal: digital input auto-fills HHA form (docxtemplater or XML)
- Paper fallback available

### Tenant notice
Draft v3 complete. Placeholders remaining: pre-app deadline, full application deadline, pre-application link.

---

## Open Items

| Item | Owner | Status |
|---|---|---|
| Confirm income threshold table by household size | Dan / Alex | Open |
| Confirm citizenship requirement (HoH vs. any occupant) | Dan | Open |
| Decide: hard vs. soft auto-denial on pre-app | Alex | Open |
| Fill in dates on tenant notice | Alex | Pending dates |
| Lobby canonical + override decisions | Alex | Blocking Phase 1 build |
| Confirm what housing authority needs to review pre-apps | Alex / HHA | Open |
