# PBV (Project-Based Voucher) Program — Planning Notes

**Source:** Internal planning conversation
**Status:** Early planning — not yet scoped for build

---

## What This Is

Stanton Management has the ability to award Section 8 / Project-Based Vouchers to existing tenants. This is not an entitlement program — it's discretionary. Tenants are waiting 15+ years on the open housing authority list; this is a shortcut that Stanton controls.

The program rollout involves two forms: a **pre-application** (quick qualification screen) and a **full application** (complete documentation).

---

## Tenant-Facing Framing (Locked)

This is a partnership, not a giveaway. The prior rollout created entitlement behavior. The messaging must:

- Lead with what we're offering and its value ("you'd otherwise wait 15 years, potentially never")
- Frame it as mutual — we want long-term tenants, good relationships, this is how we get there
- Make clear the award is discretionary and can be taken away
- Tie award eligibility to: compliance, tenant behavior, unit cleanliness, lease adherence, no undue damage

Do not frame it as "here's what you have to do." Frame it as "here's what we're building together."

---

## Program Structure

### Phase 1 — Pre-Application
- Short form, quick qualification screen
- Tenant completes within ~1 week of receiving notice
- Output: likely qualifies / does not qualify (based on income thresholds by household size)

### Phase 2 — Full Application
- Sent only to tenants who pass pre-app
- More complete documentation
- Two initiation rounds planned:
  - Round 1: ~July 1
  - Round 2: ~September 1 (for people who missed docs, needed more time)

---

## Pre-Application Fields

| Field | Notes |
|---|---|
| Head of household name | Must be adult, legally able to sign |
| Unit number | Drives bedroom count → income threshold |
| All occupants | Name, age, income per person |
| Citizenship status | At least one citizen required in household; head of household preferred |

**Qualification logic:** Income limit is based on household size and bedroom count. Table of thresholds needed (e.g., household of 2 → max ~$50k). Pre-app auto-screens against this table — if they won't qualify, don't advance them.

---

## Form Requirements

- Digital form, trilingual (EN/ES/PT)
- Digital signature
- Maps to Hartford Housing Authority application format (HC application — 2-page version identified as preferred)
- Ideally: digital input → auto-fills HHA form fields (docxtemplater or XML mapping)
- Paper form remains available as fallback

---

## Tenant Notice (To Be Drafted)

Key elements:
1. We want to build a long-term relationship with you
2. We found a way to give some of you Section 8 — something most people wait 15 years for
3. If you qualify, you pay 30–40% of income toward rent; housing authority pays the rest
4. Here's what we need from you (compliance, behavior, cleanliness)
5. Pre-application deadline + full application deadline
6. Note about pre-inspections

---

## Open Items

- Get final HHA application (HC form, full version saved)
- Confirm income threshold table by household size / bedroom count
- Confirm citizenship requirement details (head of household vs. any occupant)
- Determine whether pre-app auto-denial is hard (system blocks) or soft (staff reviews)
- Draft tenant notice copy
- Decide: does compliance matrix feed into eligibility, or is it a separate manual review?
